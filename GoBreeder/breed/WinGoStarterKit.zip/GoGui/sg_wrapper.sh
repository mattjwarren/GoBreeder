python play_gtp.py "python simple_go.py"
